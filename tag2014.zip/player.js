MainState.Player = function(game) {
};


MainState.Player.prototype = {

	preload: function() {
		
	},

	create: function() {

		
		

	},

	update: function() {
			

	}

};