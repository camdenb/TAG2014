MainState.Menus = function(game) {
};


MainState.Menus.prototype = {

	preload: function() {
		
	},

	create: function() {

		
		

	},

	update: function() {
			

	}

};