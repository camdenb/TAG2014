MainState.Overlay = function(game) {
};


MainState.Overlay.prototype = {

	preload: function() {
		
	},

	create: function() {

		
		

	},

	update: function() {
			

	}

};